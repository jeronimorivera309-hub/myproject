// app.js
document.getElementById('form-contacto').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  alert(`Gracias, ${data.nombre}. Te responderé pronto.`);
  e.target.reset();
});


// app.js
async function cargarProyectosJSON() {
  const res = await fetch('data/portfolio.json');
  const data = await res.json();
  const cont = document.getElementById('grid-proyectos');
  cont.innerHTML = data.proyectos.map(p => `
    <article class="card">
      <h3>${p.titulo}</h3>
      <p>${p.tags.join(' • ')}</p>
      <a href="${p.url}" target="_blank">Ver proyecto</a>
    </article>
  `).join('');
}

document.addEventListener('DOMContentLoaded', cargarProyectosJSON);


// app.js
async function cargarProyectosXML() {
  const res = await fetch('data/portfolio.xml');
  const xmlText = await res.text();
  const xml = new window.DOMParser().parseFromString(xmlText, 'application/xml');

  const proyectos = [...xml.querySelectorAll('proyecto')].map(node => ({
    titulo: node.querySelector('titulo')?.textContent ?? '',
    url: node.querySelector('url')?.textContent ?? '',
    tags: [...node.querySelectorAll('tags tag')].map(t => t.textContent)
  }));

  const cont = document.getElementById('grid-proyectos');
  cont.innerHTML = proyectos.map(p => `
    <article class="card">
      <h3>${p.titulo}</h3>
      <p>${p.tags.join(' • ')}</p>
      <a href="${p.url}" target="_blank">Ver proyecto</a>
    </article>
  `).join('');
}
